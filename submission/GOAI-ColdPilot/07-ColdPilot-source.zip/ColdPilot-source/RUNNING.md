# 鲜知 ColdPilot 项目运行说明

## 环境要求

- Node.js 20+ 与 pnpm
- Python 3.12
- Windows、macOS 或 Linux

## 启动后端

```powershell
cd backend
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m alembic upgrade head
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1
```

- 健康检查：`http://127.0.0.1:8000/internal/health`
- API 文档：`http://127.0.0.1:8000/internal/docs`
- 后端必须使用单 worker；当前异步任务 worker 由应用进程管理。

## 启动前端

```powershell
cd frontend
pnpm install
pnpm dev --host 127.0.0.1
```

访问：`http://127.0.0.1:5173/command-center`

HTTP 联调环境变量：

```env
VITE_DATA_MODE=http
VITE_COLDPILOT_API_BASE_URL=http://127.0.0.1:8000
```

## 可选 LLM 模式

默认 `AGENT_MODE=deterministic`，无需外部模型即可运行。若接入 OpenAI 兼容模型，仅用于基于工具结果综合诊断原因：

```powershell
$env:AGENT_MODE = "llm"
$env:LLM_BASE_URL = "https://your-provider.example/v1"
$env:LLM_API_KEY = "your-key"
$env:LLM_MODEL = "your-model"
```

LLM 不参与安全校验、审批、控制命令或执行。

## 质量门禁

```powershell
cd frontend
pnpm typecheck
pnpm test
pnpm lint
pnpm build

cd ..\backend
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m ruff check app tests
```

## 数据与设备边界

- 当前冷库、传感器、库存、异常和候选方案来自演示种子数据。
- 仿真器采用一阶热力学近似；结果需由真实冷库数据校准。
- 当前执行为仿真回放，不连接真实 PLC。
- 正式接入设备时，需在边缘侧再次实施参数白名单、硬边界、变化速率、人工接管和传统控制回退。
